This ZIP file contains the first generation of Efterian EFTs. There are 1000 Efterians included.

You have full free ownership of all of these EFTs. You are highly encouraged to use, modify, customize, and distribute them. Your only limit is your own creativity.

These EFTs were made by mjdxp. Hashlips Art Engine was used to generate all of the images.

Thank you for joining the fight against the NFT trend. By embracing EFTs, you are helping to prevent scams, save the environment, and helping out artists.

GitHub repo where you can find all of the layers used in image generation: https://github.com/mjdxp/efterians

Hashlips Art Engine: https://github.com/HashLips/hashlips_art_engine